import { Component } from '@angular/core';

@Component({
  templateUrl: './bemVindo.component.html'
})
export class BemVindoComponent {
  public tituloPagina = 'Bem Vindo';
}
