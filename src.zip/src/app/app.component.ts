import { Component } from '@angular/core';

@Component({
  selector: 'jedi',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  titulo = 'Academia Jedi';
}
